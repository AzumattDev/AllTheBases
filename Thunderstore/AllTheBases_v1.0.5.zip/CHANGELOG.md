| `Version`   | `Update Notes`                                                                                        |
|-------------|-------------------------------------------------------------------------------------------------------|
| 1.0.5       | - Add a configuration option for base unarmed damage by request.                                      |
| 1.0.3/1.0.4 | - Live updating the health could cause death or death loop (if your character saved). Prevented that. |
| 1.0.2       | - Fixed JC/EL compatibility                                                                           |
| 1.0.1       | - Fixed some wording and default values in the config                                                 |
| 1.0.0       | - Initial Release                                                                                     |
